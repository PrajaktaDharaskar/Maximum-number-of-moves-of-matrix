package com.project.maxmove;

import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of row (m): ");
		int m = sc.nextInt();
		System.out.println("Enter the number of columns(n):");
		int n=sc.nextInt();
		
		int[][]grid = new int [m][n];
		System.out.println("Enter the elements of the matrix:");
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				grid[i][j]=sc.nextInt();
			}
		}
		MaxMovesMatrix mx= new MaxMovesMatrix();
		mx.maxMoves(grid);
		
		System.out.println("Maximum number of moves:"+ mx);
	}

}
