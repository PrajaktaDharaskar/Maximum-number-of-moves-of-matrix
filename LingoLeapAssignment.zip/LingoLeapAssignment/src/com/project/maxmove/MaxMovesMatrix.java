package com.project.maxmove;

public class MaxMovesMatrix {
	public static int maxMoves(int[][] grid)
	{
		int m=grid.length;
		int n=grid[0].length;
		int[][] dp = new int[m][n];
		
		for(int col=0;col<n;col++)
		{
			for(int row=0;row<m; row++)
			{
				dp[row][col]=1;
				for(int dr=-1;dr<=1;dr++)
				{
					int newRow=row+dr;
					if(newRow>=0 && newRow<m&& grid[newRow][col]>grid[row][col-1])
					{
						dp[row][col]=Math.max(dp[row][col], dp[newRow] [col-1]+1);
						
					}
				}
			}
		}
		int maxMoves=0;
		for(int i=0;i<m;i++)
		{
			maxMoves=Math.max(maxMoves, dp[i][n-1]);
		}
		return maxMoves;
	}
}